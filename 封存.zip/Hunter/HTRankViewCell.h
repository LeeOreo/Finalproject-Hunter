//
//  HTRankViewCell.h
//  Hunter
//
//  Created by 李育豪 on 2015/5/10.
//  Copyright (c) 2015年 ALPHACamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTRankViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *rankPhoto;

@property (strong, nonatomic) IBOutlet UILabel *rankPoint;

@property (strong, nonatomic) IBOutlet UILabel *rankLevel;

@end
