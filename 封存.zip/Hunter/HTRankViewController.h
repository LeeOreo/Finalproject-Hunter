//
//  HTRankViewController.h
//  Hunter
//
//  Created by 李育豪 on 2015/5/9.
//  Copyright (c) 2015年 ALPHACamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTRankViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;


@end
